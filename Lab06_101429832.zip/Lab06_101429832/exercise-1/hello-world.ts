function helloWorld() {
    console.log("Hello, World!");
}
helloWorld();

