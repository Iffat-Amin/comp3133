"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var customer_1 = require("./customer");
var customer1 = new customer_1.Customer("Alice", "Johnson", 25);
customer1.greeter();
customer1.getAge();
