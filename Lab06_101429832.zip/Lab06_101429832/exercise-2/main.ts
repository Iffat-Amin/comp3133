import { Customer } from "./customer";

const customer1 = new Customer("Alice", "Johnson", 25);
customer1.greeter();
customer1.getAge();
